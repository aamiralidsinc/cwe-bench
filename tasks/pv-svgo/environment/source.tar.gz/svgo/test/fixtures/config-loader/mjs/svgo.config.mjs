export default {
  plugins: ['mjs'],
};

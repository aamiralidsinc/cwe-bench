#!/usr/bin/env python3
"""Check that a re-run uses the same scenario as our original DeepSeek runs.

Before running:   python3 check_same_setup.py
After running:    python3 check_same_setup.py my_runs/deepseek-x3
"""
import glob
import hashlib
import json
import os
import subprocess
import sys

HERE = os.path.dirname(os.path.abspath(__file__))
OURS = os.path.join(HERE, "runs", "attempts2-3", "config.json")
ok = True


def report(passed, msg):
    global ok
    ok = ok and passed
    print(("  OK    " if passed else "  DIFF  ") + msg)


print("1. Task files unchanged (instruction, Dockerfile, tests, fix)")
for line in open(os.path.join(HERE, "task.sha256")):
    digest, path = line.strip().split(None, 1)
    full = os.path.join(HERE, path)
    same = os.path.exists(full) and hashlib.sha256(open(full, "rb").read()).hexdigest() == digest
    if not same:
        report(False, "%s was changed or is missing" % path)
report(ok, "all task files match the ones we ran")

print("2. Harbor version")
try:
    v = subprocess.run(["harbor", "--version"], capture_output=True, text=True).stdout.strip()
except FileNotFoundError:
    v = "not installed"
report(v.startswith("0.24.0"), "harbor %s (we used 0.24.0)" % v)

if len(sys.argv) > 1:
    job = sys.argv[1]
    print("3. Run settings vs ours (%s)" % job)
    theirs = json.load(open(os.path.join(job, "config.json")))
    ours = json.load(open(OURS))
    a, b = theirs["agents"][0], ours["agents"][0]
    report(a["name"] == b["name"], "agent: %s (ours: %s)" % (a["name"], b["name"]))
    report(a["model_name"] == b["model_name"], "model: %s (ours: %s)" % (a["model_name"], b["model_name"]))
    report(a.get("kwargs") == b.get("kwargs"), "reasoning settings (thinking enabled, reasoning_effort=max, max_output_tokens 384000)")
    report(theirs.get("agent_timeout_multiplier") == 1000.0, "agent_timeout_multiplier: %s (ours: 1000 = no time limit)" % theirs.get("agent_timeout_multiplier"))
    print("4. Results")
    for p in sorted(glob.glob(os.path.join(job, "*", "verifier", "details.json"))):
        d = json.load(open(p))
        failed = [t["test"] for t in d["security"]["tests"] if t["outcome"] != "passed"]
        print("  %s  reward=%s  security %d/%d  functional %s/%s" % (
            p.split(os.sep)[-3], d["reward"], d["security"]["passed"], d["security"]["total"],
            d["functional"].get("passed"), d["functional"].get("total")))
        for t in failed:
            print("      failed: " + t)
    for p in sorted(glob.glob(os.path.join(job, "*", "exception.txt"))):
        print("  %s  crashed (infrastructure error, not a model result); see exception.txt" % p.split(os.sep)[-2])

print("\nSAME SETUP" if ok else "\nSETUP DIFFERS: results are not directly comparable with ours")

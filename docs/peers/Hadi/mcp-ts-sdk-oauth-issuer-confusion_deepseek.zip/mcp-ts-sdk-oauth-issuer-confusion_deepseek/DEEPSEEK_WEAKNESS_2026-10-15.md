# DeepSeek weakness: it fixes the security check but misses the code that feeds the check

**Model tested:** DeepSeek V4.1 Flash (`deepseek/deepseek-flash`, thinking enabled, `reasoning_effort: max`)
**Date:** 2026-10-15

## 1. Summary

When a security fix needs two changes, DeepSeek reliably makes the first and misses the second:
1. **The check:** the place that decides "allowed or not". The bug report points here.
2. **The data producer:** the code that creates, loads or converts the data the check depends on, such as a schema, parser, loader or constructor. It usually lives in another file or package, and the report does not mention it. In every failure so far, the check does **not** call this code; it runs on a separate path (for example when the app saves and reloads data).

DeepSeek fixes the check every time, and it never breaks normal behaviour. But it misses the data producer, so the attack still works through that path.

- **Fails:** 8 out of 8 runs where an unreported data-producer bug was present failed, and all 8 missed exactly the same 5 tests. 3 of those 8 were on a real, unmodified open-source repo (pass@3 = 0).
- **Scope:** all 8 failures are on one codebase (MCP TypeScript SDK). A second real repo is still running and may narrow the claim (section 3).
- **Solved:** with only the check broken, it solves the task (1/1). It also solves it when we add one sentence to the report pointing at the second path (3/3).

So the problem is **finding** the second place, not **fixing** it.

## 2. How we tested

- **Harness:** Harbor 0.24.0 with the `terminus-2` agent. The model works inside a Docker container, has no internet, and has no time limit.
- **Task image:** the repo is checked out at the vulnerable state. There is no git history and no advisory text, so the model cannot look up the fix.
- **Report given to the model:** impact-only. It describes what an attacker can do, with no fix location and no payload.
- **Hidden tests:** run after the model finishes.
  - **Security tests:** fail on the vulnerable code and pass on the correct fix. Each one tests an outcome, never error text.
  - **Functional tests:** normal behaviour must keep working.
- **Score:** security tests passed ÷ total. The score is 0 if any functional test fails. **Any score below 1.0 counts as a failure.**
- **Pass bar:** a task counts as "DeepSeek fails" when all 3 attempts score below 1.0 (pass@3 = 0).
- **Task validation:** every task was checked twice with the real upstream fix (it must score 1.0) and once with no change (it must score 0.0).

## 3. Real repos (unmodified vulnerable code, nothing injected)

### Real repo 1: MCP TypeScript SDK: DeepSeek fails 3/3

- **Repo:** `modelcontextprotocol/typescript-sdk`, at vulnerable commit `ef39308e`, the parent of the official fix `edd12e28`.
- **Advisory:** GHSA-6qxp-vccf-f47h (CWE-522), published 2026-10-06.
- **Bug:** the OAuth client sends its credentials (client secret, refresh token) to whatever authorization server a malicious MCP server names.
- **Report given:** "Our client sent its secret to the attacker's authorization server when we called `fetchToken()`." It also says, in one abstract sentence, that this covers "credentials the application saved from an earlier sign-in".
- **The two places the fix needs:**
  - **Check:** the token-request code (`fetchToken` and friends) must refuse credentials that belong to a different issuer.
  - **Data producer:** the core auth **schemas** (zod) strip the `issuer` field. When an app saves credentials and loads them back through the SDK schemas, the issuer is gone, so the check has nothing to compare and lets them through.

| Attempt | Score | Reported-check tests | Saved-credential tests | Functional tests |
|---|---|---|---|---|
| 1 | 0.64 | 9/9 pass | **0/5** | 14/14 pass |
| 2 | 0.64 | 9/9 pass | **0/5** | 14/14 pass |
| 3 | 0.64 | 9/9 pass | **0/5** | 14/14 pass |

- **Task folder:** `03_build/tasks/mcp-ts-sdk-oauth-issuer-confusion`
- **Run folders:** `data/harbor_jobs/20261015-1126-...-deepseek-t1` and `data/harbor_jobs/20261015-1553-...-deepseek`

### Second real repo: Semaphore UI (Go): still running, may NOT confirm

- **Repo and bug:** `semaphoreui/semaphore`, at real vulnerable commit `419c655d` (GHSA-cxvf-gvfq-36w2). A project manager gets owner powers through a custom role named like a built-in role.
- **The two places the fix needs:**
  - **Check:** the permission middleware.
  - **Data producer:** the database role loader, which is not limited to the current project.
- **Status:** 3 DeepSeek attempts were still running when this was written, so there are no scores yet.
- **Early logs:** at least two attempts had already edited the role loader. DeepSeek is likely finding the data producer here.
- **Likely reason:** in Semaphore, the check *calls* the role loader directly, so following calls from the check leads straight to it. In the MCP SDK, the check never calls the schema; the app uses the schema separately when it saves and reloads credentials.
- **If Semaphore is solved,** the weakness is narrower: **DeepSeek misses a data producer that the check does not call** (one that sits on a separate path). This still fits all 8 failures above.
- **Task folder:** `03_build/tasks/exp-semaphore-B`

## 4. Controlled experiments (why it fails)

All of these use the same MCP SDK snapshot with the real upstream fix put back in part. Only one thing changes between variants.

| Variant | What is broken | Report | DeepSeek result |
|---|---|---|---|
| **A** | check only | same as B | **solved** 1/1 (1.0) |
| **B** | check + data producer (schemas) | does not mention the schema path | **failed 3/3** (0.64 each, same 5 tests) |
| **B2** | same as B | B + one extra sentence (below) | **solved 3/3** (1.0 each) |
| **B3** | same as B, with every "this is intentional / backward compatible" comment removed | same as B | **failed 1/1** (0.64, same 5 tests) |
| **D** | B's bug + a second, different bug | both described | **failed 1/1** (0.55, the same 5 tests + C's 4) |
| S2only | data producer only, check already fixed | same as B | not finished |

**The one sentence that makes DeepSeek succeed (B2):**
> "We also reproduced the same leak in a second way: an application that persists its tokens and client registration and loads them back through the SDK's own token and client-information schemas, then connects ... to an MCP server that names a different authorization server, also ends up presenting those stored credentials to that server."

**What this shows:**
- **A vs B:** the reports are identical, so the only difference is the unreported data-producer bug.
- **B vs B2:** a single pointer to the path is enough. DeepSeek can fix it; it just doesn't find it.
- **B3:** the misleading code comments are not the cause. It still misses the bug without them.

## 5. What DeepSeek actually does (from reading its run logs)

1. It searches for related code by following **calls into the check**: who calls the token request, and which other functions reach it. It finds those well.
2. It never asks **where the check's data comes from**, i.e. whether the `issuer` value survives saving and loading.
3. It sees the fail-open branch ("credential has no issuer, allow it") and keeps it for backward compatibility. All 4 B-type runs we analysed did this, and 3 of them had the `.strip()` that drops the field on screen.
4. It verifies its fix with type checks, lint and the repo's existing ~980 tests. None of those save and reload credentials, so everything passes and it stops, believing the fix is complete.
5. It never breaks functionality: 0 functional failures across all runs.

## 6. What does NOT break DeepSeek (all solved, 1.0)

| Task | Shape | Result |
|---|---|---|
| seroval, zapros (real) | one missing check, or several similar spots in the same file | solved |
| Zope AccessControl: bug in 1 of 2 implementations | a fixed copy sits next to the broken one | solved |
| Zope AccessControl: bug in both C and Python implementations | parallel copies of the same check | solved |
| pymongo URI parsing: 3 code paths | parallel copies of the same check | solved |
| GitPython / jackson-core / pydantic-ai, single location | one reported location | solved |

**Rule of thumb:** repeated copies of the *same check* do not fool it. A separate *data producer* does.

## 7. Related failures (supporting evidence, different shape)

| Task | Result | What it missed |
|---|---|---|
| MCP variant C (cross-client data leak) | 0.73 | It found the real cause early, then argued itself out of it, because the right fix refuses a setup the report made sound normal. It patched another layer instead. |
| GitPython: 6 locations | 0.29 | It fixed the reported tag function and missed 5 other functions (different option-injection gaps). |
| pydantic-ai: leak + deadlock | 0.60 | It fixed the reported slot leak and missed a separate deadlock the same fix covered. |

These show DeepSeek rarely looks beyond what the report describes. They are not the same mechanism, so they are kept apart from the core claim.

## 8. How to build more tasks that DeepSeek fails

Look for real security fixes where:
1. the fix touches a **check** AND a **data producer** (schema, serializer, parser, loader, constructor) in a different file or package, and the check does **not** call that producer (it runs on a separate path);
2. fixing only the check still leaves an attack path, so its tests still fail;
3. the report can describe the impact through the check's path only, without naming the producer.

**Avoid:**
- fixes where the check cannot even compile without the producer change, because then the model is forced to find it (example: the MCP *Python* SDK version of the same bug);
- hidden tests that require a field or function name the model would have to guess.

This shape is rare: in about 45 multi-file fixes we read, only about 5 had it.

## 9. Machine-readable summary

```json
{
  "model": "deepseek/deepseek-flash (thinking, reasoning_effort=max), Harbor terminus-2, no time limit, no network",
  "weakness": "Fixes the reported security check but misses a required fix in the data producer (schema/loader/parser) in another module that the check depends on but does not call",
  "core_evidence": {
    "runs_with_unreported_producer_bug": 8,
    "failed": 8,
    "same_missed_tests_every_time": true,
    "functional_regressions": 0
  },
  "real_repos": [
    {"repo": "modelcontextprotocol/typescript-sdk", "advisory": "GHSA-6qxp-vccf-f47h", "vulnerable_commit": "ef39308e", "deepseek_scores": [0.6429, 0.6429, 0.6429], "pass_at_3": 0},
    {"repo": "semaphoreui/semaphore", "advisory": "GHSA-cxvf-gvfq-36w2", "vulnerable_commit": "419c655d", "status": "still running when written; early logs show DeepSeek editing the producer (the check calls it directly), so it may not confirm"}
  ],
  "controls": {
    "check_only_broken": "solved 1/1",
    "report_hints_second_path": "solved 3/3",
    "misleading_comments_removed": "still failed 1/1"
  },
  "does_not_break_it": ["single missing check", "same check repeated in parallel copies", "fixed reference copy next to the broken code"]
}
```

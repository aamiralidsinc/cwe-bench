# Reproduce: DeepSeek fails the real MCP SDK task 3/3

This folder has everything needed to re-run the task yourself and check the results: the task, the hidden tests, the official fix, and the logs of our 3 DeepSeek runs.

## What's in this folder

| Path | What it is |
|---|---|
| `task/instruction.md` | **The exact report DeepSeek receives.** It describes the impact only, with no fix location. |
| `task/task.toml` | Task metadata: repo, advisory, vulnerable commit, fix commit, timeouts, no network. |
| `task/environment/Dockerfile` | Builds the vulnerable repo image: real commit `ef39308e` (the parent of fix `edd12e28`), no git history, no advisory text. |
| `task/tests/` | **Hidden tests**, copied in only after the model finishes. `security.test.ts` (14 tests), `functional.test.ts` (14 tests), `score.mjs` (scoring), `test.sh` (runs both). |
| `task/solution/fix.patch` | The official upstream fix (`edd12e28`, source files only). Used by the "oracle" check. |
| `runs/attempt1/` | DeepSeek attempt 1 (Harbor job folder). |
| `runs/attempts2-3/` | DeepSeek attempts 2 and 3 (one Harbor job, two trials). |
| `runs/*.harbor.log` | Harbor's console output for each job. |
| `config/harbor_deepseek.env.example` | Template for your API key. **No real key is included.** |
| `DEEPSEEK_WEAKNESS_2026-10-15.md` | The full write-up of the weakness. |
| `task.sha256` | Checksums of the exact task files we ran. |
| `check_same_setup.py` | Checks that your run matches ours, then prints your results. |

Each trial folder under `runs/` contains:
- `agent/trajectory.json`: every step DeepSeek took (its reasoning, commands and outputs).
- `agent/recording.cast`: a terminal recording (play it with `asciinema play`).
- `verifier/reward.txt`: the final score.
- `verifier/details.json`: pass/fail for every test.
- `verifier/security.log` and `verifier/functional.log`: the test output.

## The task in one paragraph

- **Repo:** `modelcontextprotocol/typescript-sdk`.
- **Advisory:** GHSA-6qxp-vccf-f47h. A malicious MCP server can name its own authorization server and receive the client's OAuth credentials.
- **What a full fix needs:**
  1. **The check:** the token-request path (`fetchToken()` and friends) must refuse credentials meant for another issuer.
  2. **The data producer:** the core auth schemas (zod) strip the `issuer` field. Credentials an app saves and loads back through those schemas lose their issuer, so they slip past the check.
- **What the report says:** it describes the `fetchToken()` symptom. It mentions saved credentials in one abstract sentence only.

## Our results (DeepSeek V4.1 Flash, max reasoning)

| Attempt | Score | Security tests | Functional tests | Missed |
|---|---|---|---|---|
| 1 | 0.6429 | 9/14 | 14/14 | the 5 "credentials persisted by the application and validated on load with the SDK schemas" tests |
| 2 | 0.6429 | 9/14 | 14/14 | the same 5 |
| 3 | 0.6429 | 9/14 | 14/14 | the same 5 |

**Score rule:** security tests passed ÷ 14, or 0 if any functional test fails. Any score below 1.0 is a failure, so this is pass@3 = 0.

## Keep it the same scenario (important)

Our result only applies if your run matches ours. Before and after running, check these:

1. **Do not edit anything in `task/`.** That includes the instruction, the Dockerfile, the tests and the fix. Changing the report wording changes the experiment: one extra sentence pointing at saved credentials makes DeepSeek solve it (3/3 in our tests). `task.sha256` lists the exact files we ran.
2. **Same harness:** Harbor **0.24.0** with the **`terminus-2`** agent. Cursor, Claude Code or other agents are a different test.
3. **Same model and reasoning:** `deepseek/deepseek-flash` with thinking enabled, `reasoning_effort: max` and max output 384000 tokens. Lower reasoning is a different test.
4. **No time limit:** `--agent-timeout-multiplier 1000`. Don't count a timeout as a model failure.
5. **No internet inside the task:** this is already set in `task.toml`. Don't change it.
6. **Crashes are not results:** if a trial has an `exception.txt` and no `reward.txt`, it broke for infrastructure reasons (for example Docker restarting). Re-run that trial.
7. **The model can change:** DeepSeek may update the model behind the same name. Note the date of your run.

Check automatically:
```bash
python3 check_same_setup.py                      # before: task files + Harbor version
python3 check_same_setup.py my_runs/deepseek-x3  # after: settings vs ours + results per attempt
```

## How to re-run it

### Requirements
- Docker running, with at least about 8 GB of memory for Docker.
- Harbor 0.24.0 (`harbor --version`). Install it from the Harbor project if you don't have it.
- A DeepSeek API key.

### 1. Add your key
```bash
cp config/harbor_deepseek.env.example config/harbor_deepseek.env
# edit config/harbor_deepseek.env and paste your key
chmod 600 config/harbor_deepseek.env
```

### 2. Check the task itself (optional, about 10 min, no API key needed)
```bash
# Official fix applied -> expect reward 1.0
harbor run -a oracle -p task -o my_runs --job-name check-oracle -y
# Nothing changed -> expect reward 0.0 (all 14 functional tests still pass)
harbor run -a nop -p task -o my_runs --job-name check-nop -y
```

### 3. Run DeepSeek 3 times (exactly our settings)
```bash
harbor run -a terminus-2 -m deepseek/deepseek-flash \
  --env-file config/harbor_deepseek.env \
  -k 3 -n 3 -p task -o my_runs --job-name deepseek-x3 -y \
  --agent-timeout-multiplier 1000 \
  --ak 'llm_call_kwargs={"extra_body":{"thinking":{"type":"enabled"},"reasoning_effort":"max"}}' \
  --ak 'model_info={"max_input_tokens":1000000,"max_output_tokens":384000,"input_cost_per_token":0,"output_cost_per_token":0}'
```
- `-k 3` runs 3 attempts, and `-n 3` runs them in parallel.
- `--agent-timeout-multiplier 1000` means effectively no time limit.
- Each attempt took about 20 to 40 minutes for us.

### 4. Read your results
```bash
cat my_runs/deepseek-x3/*/verifier/reward.txt
python3 -c "import json,glob
for p in glob.glob('my_runs/deepseek-x3/*/verifier/details.json'):
    d=json.load(open(p)); print(p.split('/')[2], d['reward'])
    [print('   FAILED:', t['test']) for t in d['security']['tests'] if t['outcome']!='passed']"
```
If the weakness reproduces, you will see 0.6429 with the 5 "credentials persisted by the application..." tests failing.

## Notes
- **Network:** the task runs with `network_mode = "no-network"`. Harbor needs the small `alpine` image cached locally for its network check. Run `docker pull alpine` once if a run fails at startup.
- **Image contents:** the image needs `tmux` and `asciinema` for the agent, and already includes both.
- **Partial scores are expected:** a score like 0.64 is a real, valid result. The model passed some security tests and broke nothing.
- **Results vary between runs:** your scores may differ from ours. Our 3 runs all failed on exactly the same 5 tests.

// Scores the vitest JSON reports: reward = 0 if any functional test fails (or a suite did not
// run), otherwise security passed / security total.
import fs from 'node:fs';

const EXPECTED = { security: 14, functional: 14 };

function load(name) {
    const path = `/logs/verifier/${name}.json`;
    let report;
    try {
        report = JSON.parse(fs.readFileSync(path, 'utf8'));
    } catch {
        return { ran: false, tests: [] };
    }
    const tests = [];
    for (const file of report.testResults ?? []) {
        for (const a of file.assertionResults ?? []) {
            tests.push({ test: a.fullName ?? a.title, outcome: a.status === 'passed' ? 'passed' : a.status === 'failed' ? 'failed' : a.status });
        }
        if ((file.assertionResults ?? []).length === 0 && file.status === 'failed') {
            tests.push({ test: `${file.name} (suite failed to run)`, outcome: 'failed', message: String(file.message ?? '').slice(0, 2000) });
        }
    }
    return { ran: true, tests };
}

const sec = load('security');
const fun = load('functional');

const secCounted = sec.tests.filter(t => t.outcome === 'passed' || t.outcome === 'failed');
const secPassed = secCounted.filter(t => t.outcome === 'passed').length;
const secTotal = Math.max(secCounted.length, EXPECTED.security);
const funPassed = fun.tests.filter(t => t.outcome === 'passed').length;
const funFailed = fun.tests.filter(t => t.outcome !== 'passed').length + Math.max(0, EXPECTED.functional - fun.tests.length);

let reward;
if (!sec.ran || !fun.ran || secTotal === 0 || funFailed > 0) reward = 0;
else reward = secPassed / secTotal;

fs.writeFileSync('/logs/verifier/reward.txt', `${reward.toFixed(4)}\n`);
fs.writeFileSync(
    '/logs/verifier/details.json',
    JSON.stringify(
        {
            reward,
            security: { passed: secPassed, total: secTotal, tests: sec.tests },
            functional: { passed: funPassed, failed: funFailed, total: Math.max(fun.tests.length, EXPECTED.functional), tests: fun.tests }
        },
        null,
        2
    )
);
console.log(`security ${secPassed}/${secTotal}, functional failures ${funFailed} -> reward ${reward.toFixed(4)}`);

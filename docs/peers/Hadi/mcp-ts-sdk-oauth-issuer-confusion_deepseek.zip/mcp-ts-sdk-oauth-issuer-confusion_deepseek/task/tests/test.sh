#!/bin/bash
# Hidden verifier: runs the security and functional suites separately (offline, with the
# vitest already installed in the image) against the SDK source in /app, then scores them.
mkdir -p /logs/verifier
APP=/app
VITEST="$APP/packages/client/node_modules/vitest/vitest.mjs"

# Work from a pristine copy of the hidden tests outside the repo; resolve vitest and the
# SDK's third-party dependencies through the client package's installed node_modules.
WORK=/tmp/klavis-verifier
rm -rf "$WORK" && mkdir -p "$WORK"
cp -r /tests/. "$WORK"/
rm -rf "$WORK/node_modules"
ln -s "$APP/packages/client/node_modules" "$WORK/node_modules"
cd "$WORK"

export CI=true NO_COLOR=1 FORCE_COLOR=0 MCP_APP_ROOT="$APP"

run_suite() {
    local name="$1"
    rm -f "/logs/verifier/${name}.json"
    timeout 600 node "$VITEST" run --config "$WORK/vitest.config.mjs" --root "$WORK" \
        --reporter=verbose --reporter=json --outputFile.json="/logs/verifier/${name}.json" \
        "${name}.test.ts" 2>&1 | tee "/logs/verifier/${name}.log"
}

run_suite security
run_suite functional

node "$WORK/score.mjs" || {
    echo "0.0000" > /logs/verifier/reward.txt
    echo '{"reward": 0, "error": "scoring failed"}' > /logs/verifier/details.json
}
exit 0

Below is a vulnerability report for an open-source project. You have NO access to the code. Using only your own knowledge of the project and of this kind of bug, state where the root cause most likely lives.

Reply with ONLY a JSON object: {{"files": ["<repo-relative file paths, best guesses>"], "functions": ["<function/class names>"], "fix_summary": "<one or two sentences>"}}. If you do not recognise the project, still give your best guess.

# Report
{report}

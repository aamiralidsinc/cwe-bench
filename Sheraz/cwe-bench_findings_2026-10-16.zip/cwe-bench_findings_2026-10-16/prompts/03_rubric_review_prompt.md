You are a strict reviewer of tasks in a security-fix benchmark. An AI agent will receive ONLY the report (instruction.md) and
the vulnerable repository, must fix the vulnerability, and is graded by the hidden tests. The oracle patch is the historical
human fix and must pass every test. Judge the task, not the code style.

# instruction.md (given to the agent)
{instruction}

# hidden_tests.py (never shown to the agent)
```python
{tests}
```

# Oracle patch (source files only)
```diff
{patch}
```

# Declared entry point (internal metadata)
{entry_point}

# Criteria (answer each; "critical" ones must all pass)
{criteria}

Respond with ONLY a JSON object:
{{"criteria": {{"<name>": {{"pass": true|false, "reason": "<one or two sentences, cite the offending text if failing>"}}, ...}},
  "blocking_issues": ["<short issue>", ...]}}

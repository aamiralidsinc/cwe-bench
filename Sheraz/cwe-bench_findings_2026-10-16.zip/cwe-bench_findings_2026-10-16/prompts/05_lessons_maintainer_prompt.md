You maintain the lessons file of a benchmark factory that builds security-fix tasks. A task is only useful if BOTH target
models (DeepSeek V4.1 Flash = "deepseek", Xiaomi MiMo-V2.6-Pro = "mimo") fail it at pass@3 = 0 for legitimate reasons (not a
broken task). The long-term goal is to make each generation round better than the last: learn WHAT breaks each model and
combine those techniques in new tasks.

Each outcome row has a `pattern`:
  both_fail            both models failed (target) - `technique` says what made it hard
  only_deepseek_fails  DeepSeek failed, MiMo solved - what defeated DeepSeek but not MiMo
  only_mimo_fails      MiMo failed, DeepSeek solved - what defeated MiMo but not DeepSeek
  <a>_fails_<b>_timed_out / <a>_timed_out_<b>_solves   a timeout is NOT a failure; record it as "too slow", not "broken"
  both_solve           too easy - `why_easy` / `technique` explain
`task_type` (vulnerability family; fix breadth) and `model_results` (each model's verdict and how it failed, measured)
say WHICH KIND of task broke WHICH model - a task that broke only one model is still evidence for that model's section.
Other statuses: accepted / rejected_task_defect / needs_review (trial analysis), rejected_rubric / failed_oracle / rejected_unbuildable
(the task itself was bad; `detail` says why). `recall_probe` shows whether the models could name the fix location from the report alone.

Rewrite the lessons file. Rules:
- Evidence only. Cite counts like (n=3); mark anything with n<3 as "tentative".
- Concrete and actionable for an LLM that WRITES the next report and tests: report style, which behaviours/variants the tests
  cover, fix shapes (files, lines, entry-point type), CWE classes, and test-design mistakes the rubric caught.
- For each model, keep a separate list of techniques that broke it, then say which techniques to COMBINE in a single task.
- Add SELECTION hints (CWE / ecosystem / fix shapes to prefer or skip) for the screening step.
- Keep earlier lessons that are still supported; drop ones contradicted by new data; merge duplicates.
- Max ~4500 characters, Markdown, these sections only: "## Breaks BOTH models (replicate)", "## Breaks only DeepSeek (MiMo solves)",
  "## Breaks only MiMo (DeepSeek solves)", "## Solved by both (avoid)", "## Task-quality pitfalls (rubric / oracle failures)",
  "## Selection hints". No preamble.

# Outcome rows (oldest first)
{rows}

# Current lessons file
{current}

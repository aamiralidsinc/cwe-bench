

# Task-design techniques (curated - follow them)
## What counts as a model failure (the grading contract)
- A task is solved only by reward 1.0: every hidden security test, every hidden functional test and every enforced
  existing repo test passes. Anything less is a FAILURE, including:
  - **Partial fix:** the agent closes some attack paths but not all (e.g. 5 of 6 security variants blocked). This is the
    most valuable failure: the model was confident and wrong ("silent failure").
  - **Fix that breaks something:** the hole is closed but a legitimate behaviour, an existing repo test, or the build
    breaks (over-correction / regression).
  - Both at once.
- A task is ACCEPTED when every attempt of both models (3 + 3) is such a failure, and the deterministic checks prove
  each failure is the model's (graded, no API/harness crash, agent really worked, no tampering). No AI judge decides.
- The goal is to MEASURE repair quality: a task only an incomplete or over-broad repair fails is a good task.
- So every task must be designed so that (a) a partial fix still fails and (b) an over-broad fix still fails.

## What makes a repair task demanding - so only a complete, careful repair passes (use several in ONE task)
1. **Unnamed sibling path.** The report describes the reported trigger only. The same root cause is reachable through
   a second entry point, a second code path, or a round-trip (serialize -> store -> parse) that the report never
   names. Give it its own security test. Evidence: DeepSeek missed the schema round-trip variant in 3/3 runs on 6qxp.
2. **Already-protected-looking code.** One path already validates correctly, so the model reads the area as "handled"
   and patches only the path the report mentions (pyload jq7h, 6qxp).
3. **Fix across a layer boundary.** The correct fix must reach from the entry layer into a deeper layer (e.g. a core
   API that cannot see the web session, an SDK helper that cannot see the stored binding). Local guards at the entry
   point are the shallow fix your tests must catch.
4. **One test per variant.** Each bypass (other entry point, encoding, casing, ordering, nested input, round-trip,
   repeated call) is a separate `test_security_*`, so a fix that closes most variants still scores < 1.0.
5. **Boundary-hugging functional tests.** Legitimate inputs that look like the attack (same characters, same feature,
   trailing slash, empty/None, legacy unbound data) must keep working, so "reject everything suspicious" fails.
6. **Behavioural report, no localization.** Describe what a user observes ("an IPv6 client passed our IPv4 allowlist"),
   never the function, class, file or the root cause wording that points at the line to change.
7. **Parallel implementation.** The project has a second module that re-implements the same feature (a second
   renderer, a second parser, a legacy and a new API). The report describes the behaviour once; the fix must land in
   both. Evidence: hono GHSA-hxh3 (first ACCEPTED task) - in 4 of 6 attempts the second `jsx/dom/server` renderer was
   left unfixed (DeepSeek read it every time but argued a top-level string is "trusted HTML"; MiMo twice never looked);
   the other 2 fixed it for a bare string only and missed a nested-array root. Details: data/knowledge/failure_analyses/.
8. **Second public API / input-shape variants.** Test the lower-level constructor or helper and each input shape the
   same parameter accepts (array, nested array, bare string, path-like). Both models fix the entry point and the shape
   they reproduced, verify with probes through that same entry point, and stop (hono, nltk GHSA-p4rw).
9. **A "must keep working" clause that argues against the fix.** DeepSeek uses such a clause (or an existing test that
   passes either way) as permission to leave a sink open; MiMo over-hardens and breaks the legitimate path - test the
   legitimate behaviour in every supported composition order (undici GHSA-vp8m).
10. **Prefer big fixes.** Target real fixes of >= 6 source files, >= 100 changed lines, >= 3-4 directories. Every fix of
   <= 5 files so far was solved; tiny local fixes (<= 3 files, <= 35 lines) never gave a usable task.

## How the pipeline proves the tests are good (your check patches)
- **shallow**: blocks only the reported trigger. At least one security test must still fail on it (technique 1/4).
- **removal**: disables or over-restricts the feature. At least one functional test must fail on it (technique 5).
- **alternative**: a correct fix of a different design. Every test must pass on it (tests are implementation-agnostic).
- These are executed in the real environment. A wrong outcome sends the task back with the failing test names.

## Fairness rules (never break these to make a task harder)
- Every hidden test is passed by the reference fix and follows from the report plus a careful reading of the code.
- Tests observe only what a caller can observe at the entry point; never internal state or names the fix adds.
- No timing races, no network, no randomness.
- **Never test a number the report does not state.** The reference fix's internal limits (max length 64, a 1,000,000
  cap, a depth limit) are ONE design; another correct fix may pick another value. (Most common rejection so far:
  pypdf, source-map-js.) For resource-exhaustion bugs: keep the legitimate input small and the attack input orders of
  magnitude larger (e.g. 1x vs 1000x), and assert only that the attack is refused or finishes quickly and bounded -
  never at which exact size it starts being refused. If a boundary matters, the report must state it.
- **Variants must share the reported root cause.** Another bug in the same area (a different slow path, a different
  missing check) is a different task, not a variant (rejected: source-map-js deep nesting, typespec output files).
- **"Must keep working" means it works today.** Every functional test must pass on the vulnerable code; never describe
  as legitimate a behaviour the project never had (rejected: undici allow-list caching).

## Answer-key hygiene (the agent must use its own knowledge)
- The agent sees only the report and the repo at the vulnerable commit: no hidden tests, no fix, no git history of
  the fix, no network, no advisory text. Never put fix code, upstream regression tests or exploit inputs into the repo
  or the report. Fixes committed after the models' release dates keep the answer out of their training data.


# Which task types each evaluated agent could not repair completely (measured results)
## Model failure map (deterministic, rebuilt after every evaluation)
Task type = vulnerability family; fix breadth (files / dirs / lines). Timeouts are not failures.
### DeepSeek
- FAILED on (3): auth / session / credentials; wide multi-layer fix (8 files / 4 dirs / 174 lines) - partial fix: closed 5 of 6 attack variants in all 3 runs and stopped on its own (it thought it was done); left open every time: schema_roundtrip_keeps_binding | injection (code / command / markup); wide multi-layer fix (6 files / 3 dirs / 156 lines) - partial fix (and broke legitimate behaviour in 1 of 3 runs: runtime-tests/node/index.test.ts > stream > Should call onAbort) in all 3 runs and stopped on its own (it thought it was done); left open every time: render_to_string_escapes_array_root | path / file handling; wide multi-layer fix (10 files / 3 dirs / 236 lines) - partial fix: closed 4 of 5 attack variants in all 3 runs and stopped on its own (it thought it was done); left open every time: toolbox_symlink_escape
- Timed out on (0): none
- Solved (21), by vulnerability family: resource exhaustion (DoS) x7, auth / session / credentials x5, parsing / type confusion x3, path / file handling x2, injection (code / command / markup) + information exposure x1, other x1, information exposure x1, deserialization / prototype pollution x1
### MiMo
- FAILED on (2): injection (code / command / markup); wide multi-layer fix (6 files / 3 dirs / 156 lines) - partial fix (and broke legitimate behaviour in 1 of 3 runs: runtime-tests/node/index.test.ts > stream > Should call onAbort) in all 3 runs and stopped on its own (it thought it was done); left open every time: render_to_string_escapes_array_root | auth / session / credentials; wide multi-layer fix (10 files / 5 dirs / 120 lines) - closed the hole but broke legitimate behaviour (storage_with_custom_lookup_same_host) in its run and stopped on its own (it thought it was done)
- Timed out on (2): auth / session / credentials; wide multi-layer fix (8 files / 4 dirs / 174 lines) | auth / session / credentials; wide multi-layer fix (5 files / 4 dirs / 111 lines)
- Solved (3), by vulnerability family: parsing / type confusion x2, path / file handling x1
### Broke BOTH (replicate this shape): injection (code / command / markup); wide multi-layer fix (6 files / 3 dirs / 156 lines)


# Why the evaluated agents failed real tasks (curated from their trajectories - design for these)
## GHSA-hxh3-vqpv-xpqv: ACCEPTED - both models failed all 3 attempts (DeepSeek 0.83/0.83/0.94, MiMo 0.89/0.94/0.89, Claude Code agent), every run stopped on its own (no timeout). All 6 fixed the three wrappers the report names (Suspense, ErrorBoundary, Context.Provider) and all 6 left `renderToString([unsafe, [unsafe]])` unescaped.
#### Weakness profile
- Shared: both treat the report's examples as the complete list of sinks, and fix only the input shape they
  reproduced (a bare string) even when the same parameter accepts arrays, nested arrays and promises.
- DeepSeek: over-reasons about intent - finds the sink, then uses a "keep legitimate behaviour" clause or an existing
  passing test as permission to leave it vulnerable.
- MiMo: under-explores and asserts unverified facts ("that API doesn't exist") instead of searching.
#### Task-design lessons
- Put a **second entry point in a sibling module whose path sounds out of scope** (here `dom/` reads as "client") and
  describe it only vaguely ("a string handed to the renderer directly").
- Add a **"must keep working" clause that plausibly argues against the fix** ("a bare string must still be
  renderable"), backed by an existing test that passes either way (`'Hono'` has nothing to escape).
- **Test input-shape variants at each sink** (array, nested array, promise, number), not only each sink.
- Make **two entry points share the bug but need separate fixes**; agents fix them unevenly and claim full coverage.
- List some sinks "for example" and test more than you list: every agent stopped once the listed items were covered.

## GHSA-6qxp-vccf-f47h: DeepSeek failed 3/3 (0.92 each, Claude Code agent), always closing 5 of 6 attack paths; MiMo only timed out (terminus-2, 2 h), so the task is rejected (a timeout is not a failure).
#### Weakness profile
- DeepSeek traces call graphs well but misses state that crosses a serialization boundary (save -> store -> parse).
- It trusts in-code comments and "intentional" design notes, and reads "must keep working" hints as constraints.
- It stops as soon as self-written tests (which cover only what it already believes) pass.
#### Task-design lessons
- Put one variant on a **data round-trip** (serialize -> persist -> parse through the project's own schema/model
  layer) that the report does not name; the call-path fix then leaves exactly that variant open.
- Let the vulnerable code contain a plausible "intentional" comment or an already-protected entry point near the bug.
- Mention the round-trip only as legitimate behaviour that must keep working; never as an attack path.

## GHSA-p4rw-rvv2-7xwr: DeepSeek failed all 3 attempts (0.93 each, always the toolbox symlink escape left open); MiMo failed 2 (0.87, toolbox + MTE left open) and solved 1. Rejected (MiMo solved). No timeouts; every run stopped on its own.
#### Weakness profile
- DeepSeek: entry-point blindness - treats "reachable through the main class" as the whole attack surface and
  confirms with probes that use the same entry point as its fix.
- MiMo: rationalises away its own negative evidence on an ambiguous boundary, and writes tests shaped to fit its fix.
#### Task-design lessons
- Make hidden tests hit the **second public API** (a lower-level class, helper, bare-string / path-like argument);
  the report says only "more than one public loading API".
- Let an **existing guard look sufficient in the test environment** (an allowed tempdir root) so a plausible
  half-fix passes the agent's own probes.
- Leave an **ambiguous boundary** (a bare path with no explicit root) where the report's general rule ("each affected
  path must honour the same containment rule") implies the strict reading.
- Name affected **file kinds** in the report, not readers, and test at least one reader reached only indirectly
  through a shared helper.
- Hidden tests use default arguments and the real sandbox settings, so environment-bending self-tests do not help.

## GHSA-vp8m-p9jh-q5pm: DeepSeek failed attempt 1 (0.86, 5 of 7 attack paths) then solved attempt 2; MiMo failed its one graded attempt (0.93): it closed every attack path but broke a legitimate caching behaviour. Rejected (DeepSeek solved).
#### Weakness profile
- DeepSeek: does not enumerate every place the real destination can hide; reads a class-level requirement ("however
  wrapped") narrowly; treats "my own repro passes" as proof of completeness.
- MiMo: over-hardens with redundant defence-in-depth layers; confuses the order of composed layers; tests a legitimate
  configuration in one order only and generalises ("either order should work").
#### Task-design lessons
- Phrase requirements that imply a **class of cases** ("however it is wrapped / combined") and give each member its
  own hidden security test; the example in the report should be only one member.
- Test the same **legitimate behaviour in every supported composition order**: over-restricting fixes fail only in
  the order the agent did not try (this is what breaks MiMo).
- Pair each security test with a "must still work" twin sharing its setup (same host, custom lookup, wrapper).
- Prefer missed cases that appear in the repo's own usage/tests but not in the report's reproduction steps.


# Lessons from previous runs (auto-generated from real DeepSeek/MiMo results - follow them)
## Breaks BOTH models (replicate)
- **hxh3, hono, npm, CWE-79 (accepted; tentative n=1):** 6 files / 3 dirs / 156 lines.
  - Both models stopped on their own at 0.83–0.94 in 3/3 runs.
  - Both left `render_to_string_escapes_array_root` open every run. Escaping covered the usual root but not an array root passed to render-to-string.
  - Check `stream > Should call onAbort` for flakiness. Both models "broke" it.
- **Combine in one task:**
  1. A sink reachable through ≥3 input shapes or entry points, where the obvious fix point misses one. This beat DeepSeek (n=3).
  2. One security test per shape, so closing 5 of 6 still fails.
  3. A preserved-behaviour test across a composition or ordering boundary. This beat MiMo (tentative, n=1).
  4. One path that is already correctly protected, which invites MiMo to over-verify (tentative, n=1).
  5. Fast verifier and repo suites. MiMo timeouts are not counted (6qxp).

## Breaks only DeepSeek (MiMo solves)
**Pattern (n=3: 6qxp, p4rw, hxh3).** DeepSeek patches the first layer it finds and closes every variant but one, scoring 0.92–0.94. It then declares itself done. The variant left open always bypasses the layer it patched:
- **6qxp (CWE-345/522, 8 files):** the credential binding is lost through a round-trip via the exported schemas. DeepSeek noticed this and stopped anyway. MiMo timed out 3/3, so this was too slow, not a counted pair.
- **p4rw, nltk (CWE-22/59, 10 files / 236 lines):**
  - DeepSeek put the root check in `CorpusReader.abspath`. It missed the bare-string entry points `toolbox.StandardFormat.open`, `XMLCorpusView` and `load_ace_file`, and it broke the downloader tests.
  - MiMo fixed the shared I/O layer (`FileSystemPathPointer`) and solved 1/3.
- **hxh3:** the array-root render path.

DeepSeek named the fix location in 0 of ~24 recall probes, yet solved 14 tasks. Obscurity doesn't beat it; a missed bypass path does.

## Breaks only MiMo (DeepSeek solves)
- **vp8m, undici (CWE-346, 10 files / 5 dirs; tentative n=1):**
  - MiMo closed the hole but broke reuse in `compose(cache(), dns())`. It restored the hostname only on the response side, so the lookup key and the store key diverged.
  - Its second run hung on slow suites and was not graded.
  - DeepSeek threaded a hidden real-origin field through dns, redirect and retry, and solved 1/2.
- **jq7h, pyload (CWE-613; tentative n=1):** MiMo spent its budget verifying the webui path, which was already correct. It never edited the REST entry point.
- MiMo also failed hxh3, for 3 counted failures in total.
- **MiMo is slow:** p90 step ≈400 s vs ≈40 s for DeepSeek. It timed out on 6qxp with no edits.

## Solved by both (avoid)
- **p634 (adm-zip) and j6r3 (ip-address):** the report gave the root cause, a repro and the API names, and the fix was one local check.
- **pqg4 and x33g:** both models named the fix location from the report alone.
- **DeepSeek solved on its first attempt (MiMo then skipped), n=10:** j22f, v247, 24ch, 68w4, 9q47, 77xj, 5jq2, 3wxw, hqr4 (10 files / 286 lines) and hmq2 (13 files / 232 lines).
  - This drops the old rule that "breadth beats DeepSeek". Wide fixes with a single consistent choke point were solved.

## Task-quality pitfalls (rubric / oracle failures)
- **Run every test on the vulnerable code (n=4):** security tests must fail there and functional tests must pass.
  - 8r5x: ASTs without `loc` crashed before the injection ran.
  - r4xh: a security test already passed.
  - mcm9 and vp8m: functional tests demanded new behaviour.
- **Undisclosed thresholds or required behaviour (n=3):**
  - 5jq2: a length cutoff of 64.
  - 68fv: a cap somewhere between 1M and 50M, refusal only by exception, and a hidden second root cause.
  - 2q42: had to sanitize and still emit; rejecting failed.
  - Fix: state limits in the report or use ≥100× margins, and accept both reject and sanitize.
- **Tests tied to internals (n=4):** pyload 68w4, 9q47 and jq7h, and payload qf28, which called `getSelect` directly. Test through the public or HTTP entry point.
- **Weak tests (n=4):**
  - x937 and 6qxp: weak functional tests.
  - qf28: no assertion on output content.
  - r4xh: swallowed exceptions let a forbidden size-cap fix pass.
- **Wall-clock asserts (tentative, n=1, r4xh):** use operation counts instead.
- **Oracle fails its own tests (n=7):** x6jw, p634, jggr (0.5 ×3, never fixed), 68fv, hmq2, 2q42 and hqr4.
- **Bad existing-test files (n=4):** 68fv, hqr4, r4xh and qf28 included helper, manual or DB-integration files ("no runnable test runner", "(no results)"). Exclude them.
- **Docker-compose "no verdict" (n=7):** this is infrastructure, not the task, and 5 of these tasks were validated on retry. Retry before rejecting.
- **Report names the code (n=3):** j22f, j6r3 and pqg4.
- **Classifier or safeguard blocks (n=7):** GitPython and pypdf passed on retry. Handlebars was retired.

## Selection hints
- **Prefer:**
  - Sinks reachable through several input types or entry points, where a tempting high-level choke point misses some of them (n=3; 6–10 files, 120–236 lines).
  - CWE-79, CWE-22/59 and CWE-345/522.
- **Width is not sufficient:** wide fixes have been solved (hqr4, hmq2).
- **Skip:**
  - Fixes of ≤4 files and ≤60 lines (0 usable of 11).
  - DoS and resource CWEs 400/407/674/1284 (0 usable of 8).
  - Code generators that emit another language (jhipster).
  - Heavy monorepos: payload (4 rubric/oracle failures), jhipster and pydantic-ai.
  - PyPI repos where `pip install -e .` fails or the build takes >30 min (winml-cli, sentence-transformers).
- **pyload:** keep only if the tests use the real app's test client.
- **Recall:**
  - Reject if both models name the fix location (n=2).
  - Otherwise recall does not predict difficulty. hxh3 had low recall from both and both failed; MiMo recalled vp8m yet failed; MiMo recalled p4rw and solved it.

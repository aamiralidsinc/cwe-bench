# CWE-bench findings, 2026-10-16

Results of the task factory since the MCP SDK re-run (Claude Code agent harness, DeepSeek V4.1 Flash effort max and
MiMo-V2.6-Pro, 3 attempts each, 2-hour limit, timeouts not counted). The results ledger is the separate C_RESULTS.md.

| Folder | Contents |
|---|---|
| `failing_tasks/<GHSA>/` | every task a model failed: `task/` (report given to the agent, hidden tests, reference fix, validation record) and `attempts/<model>/<trial>/` (the model's patch `agent.diff`, per-test results `ctrf.json`, `score_breakdown.json`, test output, `trajectory.json`) |
| `knowledge_base/` | what the generator learns from: `failure_analyses/` (why each model failed, from the trajectories), `model_failure_map.md`, `lessons_history/`, `task_outcomes.jsonl` |
| `prompts/` | the task generator's system prompt, the knowledge appended to it every round, the rubric review and recall-probe prompts, and `skills/` (technique guide, lessons, adversarial research guide) |
| `logs/` | pipeline run logs (one folder per run, see `logs/README.md`); `*_VOID_*` files are runs that did nothing |

Failing tasks: hono GHSA-hxh3 (ACCEPTED, both models 3/3), MCP SDK GHSA-6qxp (DeepSeek 3/3; MiMo only timed out),
nltk GHSA-p4rw (DeepSeek 3/3; MiMo solved 1/3), undici GHSA-vp8m (each model failed one attempt; DeepSeek then solved).

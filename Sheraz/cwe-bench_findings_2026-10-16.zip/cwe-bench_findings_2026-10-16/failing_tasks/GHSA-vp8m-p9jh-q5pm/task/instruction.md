# One backend's stored HTTP responses are replayed to callers of another backend

## Summary
Our Node.js service talks to several backends from one process. Each backend has its own undici `Client` or `Pool`. We attach undici's built-in HTTP response-storage interceptor to each one, and they all share one in-memory store so that memory use stays bounded. We also use the built-in interceptor that merges identical concurrent GETs.

To decide which origin a stored response belongs to, undici uses the origin label carried on the request. It does not consider which server actually received and answered the request. The same is true when it decides which in-flight requests can be merged. When the label and the real destination differ, one server's response is filed under another server's name and replayed to that server's users. This is an origin-validation weakness (CWE-346) that leads to cross-host response poisoning.

## Steps to reproduce
1. Start two loopback HTTP servers, A and B. Each answers `GET /profile` with a body that names the server and a response header allowing public storage for 300 seconds (public, max-age 300).
2. Create `new Client(A)` and `new Client(B)`. Attach the response-storage interceptor to each, with both using one shared store.
3. On the A client, issue `{ method: 'GET', path: '/profile', origin: B }`. The client is bound to A, so A answers.
4. On the B client, issue a plain `GET /profile`.

**Actual:** step 4 returns A's body, and server B is never contacted.

We think this trigger is one instance of a broader problem. The same confusion should happen whenever a request's origin label can differ from the host that really serves it. It should also happen with client objects that have no single fixed upstream.

## Impact
Anyone who can influence the origin field of a single request can plant content under a host they do not control. One example is a multi-tenant gateway that forwards user-supplied URLs. Other tenants then receive that content for the unrelated host until the entry expires.

## Expected behaviour
- A stored or in-flight response may only be reused for requests that really reach the same server and virtual host that produced it. This must hold however the client object is wrapped and whatever other interceptors it is combined with.
- These must keep working:
  - per-origin storage and reuse through `Agent`
  - repeated requests on a single-origin `Client`/`Pool` being served from storage
  - the origins allow-list option, with case-insensitive strings and regular expressions
  - merging of identical concurrent requests to one host
  - storage combined with a custom host-name lookup, as long as the host name stays the same
  - storage while following 3xx responses to another host

"""Hidden regression tests: responses must never be stored or shared across different real upstreams."""
import json
import os
import shutil
import subprocess

import pytest

REPO_ROOT = os.path.abspath(os.environ.get("REPO_ROOT") or os.getcwd())
NODE = shutil.which("node")

PRELUDE = r"""
'use strict'
const { createServer } = require('node:http')
const undici = require(process.env.UNDICI_ROOT)
const { Agent, BalancedPool, Client, Pool, RetryAgent, Dispatcher1Wrapper, cacheStores, interceptors } = undici

process.on('unhandledRejection', () => {})
process.on('uncaughtException', (err) => {
  process.stdout.write('\n__ERROR__' + JSON.stringify('uncaught: ' + String((err && err.stack) || err)) + '\n')
  process.exit(0)
})

const watchdog = setTimeout(() => {
  process.stdout.write('\n__ERROR__' + JSON.stringify('scenario timed out') + '\n')
  process.exit(0)
}, 30000)

function deferred () {
  let resolve
  const promise = new Promise(r => { resolve = r })
  return { promise, resolve }
}

function holdSpec (path) {
  return { path, arrived: deferred(), release: deferred() }
}

function listen (server) {
  return new Promise((resolve, reject) => {
    server.once('error', reject)
    server.listen(0, '127.0.0.1', () => resolve(server))
  })
}

async function labelled (label, hits, hold) {
  const server = createServer(async (req, res) => {
    hits[label] = (hits[label] || 0) + 1
    hits[label + ' ' + req.url] = (hits[label + ' ' + req.url] || 0) + 1
    if (hold && req.url === hold.path) {
      hold.arrived.resolve()
      await hold.release.promise
    }
    res.writeHead(200, { 'cache-control': 'public, max-age=300', 'x-origin': label })
    res.end(label)
  })
  await listen(server)
  const port = server.address().port
  return { server, port, origin: `http://127.0.0.1:${port}` }
}

async function vhost (hits) {
  const server = createServer((req, res) => {
    const host = String(req.headers.host || '')
    const label = host.startsWith('attacker.')
      ? 'attacker'
      : host.startsWith('trusted.') ? 'trusted' : 'other'
    hits[label] = (hits[label] || 0) + 1
    res.writeHead(200, { 'cache-control': 'public, max-age=300', 'x-origin': label })
    res.end(label)
  })
  await listen(server)
  return { server, port: server.address().port }
}

const fixedLookup = (_origin, _opts, cb) => cb(null, [{ address: '127.0.0.1', family: 4 }])

async function get (dispatcher, path, extra) {
  try {
    const { statusCode, body } = await dispatcher.request({ method: 'GET', path, ...(extra || {}) })
    const text = await body.text()
    return { status: statusCode, body: text }
  } catch (err) {
    return { error: String((err && err.message) || err) }
  }
}

function finish (result) {
  clearTimeout(watchdog)
  process.stdout.write('\n__RESULT__' + JSON.stringify(result) + '\n')
  process.exit(0)
}
"""

SUFFIX = r"""
main().then(finish, (err) => {
  process.stdout.write('\n__ERROR__' + JSON.stringify(String((err && err.stack) || err)) + '\n')
  process.exit(0)
})
"""


def run_node(tmp_path, body):
    if NODE is None:
        pytest.fail("node executable not found")
    script = tmp_path / "scenario.js"
    script.write_text(PRELUDE + "\n" + body + "\n" + SUFFIX, encoding="utf-8")
    env = dict(os.environ)
    env["UNDICI_ROOT"] = REPO_ROOT
    proc = subprocess.run(
        [NODE, str(script)], cwd=REPO_ROOT, env=env,
        capture_output=True, text=True, timeout=120,
    )
    for line in reversed(proc.stdout.splitlines()):
        if line.startswith("__RESULT__"):
            return json.loads(line[len("__RESULT__"):])
        if line.startswith("__ERROR__"):
            pytest.fail("node scenario failed: " + line[len("__ERROR__"):] + "\nstderr:\n" + proc.stderr[-3000:])
    pytest.fail("node scenario produced no result\nstdout:\n" + proc.stdout[-3000:] + "\nstderr:\n" + proc.stderr[-3000:])


def assert_ok(result, expected_body, what):
    assert "error" not in result, f"{what}: legitimate request failed: {result}"
    assert result.get("status") == 200, f"{what}: unexpected status {result}"
    assert result.get("body") == expected_body, f"{what}: expected body {expected_body!r}, got {result.get('body')!r}"


# ---------------------------------------------------------------- security


def test_security_bound_client_caller_origin_does_not_poison_shared_store(tmp_path):
    """A Client/Pool bound to A must not file A's response under a caller-chosen origin B."""
    res = run_node(tmp_path, r"""
async function main () {
  const out = {}
  for (const [name, make] of [['Client', o => new Client(o)], ['Pool', o => new Pool(o)]]) {
    const hits = {}
    const a = await labelled('A', hits)
    const b = await labelled('B', hits)
    const store = new cacheStores.MemoryCacheStore()
    const da = make(a.origin).compose(interceptors.cache({ store }))
    const db = make(b.origin).compose(interceptors.cache({ store }))
    const planted = await get(da, '/profile', { origin: b.origin })
    const v1 = await get(db, '/profile')
    const v2 = await get(db, '/profile')
    out[name] = { planted, victims: [v1, v2] }
  }
  return out
}
""")
    for name in ("Client", "Pool"):
        for i, victim in enumerate(res[name]["victims"]):
            assert_ok(victim, "B", f"{name} victim #{i}")


def test_security_multi_upstream_pools_do_not_share_entries(tmp_path):
    """Pools without a single fixed upstream must not reuse each other's responses (shared store or shared interceptor)."""
    res = run_node(tmp_path, r"""
async function main () {
  const out = {}
  {
    const hits = {}
    const a = await labelled('A', hits)
    const b = await labelled('B', hits)
    const store = new cacheStores.MemoryCacheStore()
    const da = new BalancedPool(a.origin).compose(interceptors.cache({ store }))
    const db = new BalancedPool(b.origin).compose(interceptors.cache({ store }))
    out.sharedStore = [await get(da, '/lb'), await get(da, '/lb'), await get(db, '/lb'), await get(db, '/lb')]
  }
  {
    const hits = {}
    const a = await labelled('A', hits)
    const b = await labelled('B', hits)
    const shared = interceptors.cache()
    const da = new BalancedPool(a.origin).compose(shared)
    const db = new BalancedPool(b.origin).compose(shared)
    const label = { origin: 'http://shared.example' }
    out.sharedInterceptor = [await get(da, '/lb', label), await get(da, '/lb', label), await get(db, '/lb', label), await get(db, '/lb', label)]
  }
  return out
}
""")
    for scenario in ("sharedStore", "sharedInterceptor"):
        for r, expected in zip(res[scenario], ["A", "A", "B", "B"]):
            assert_ok(r, expected, scenario)


def test_security_name_resolution_does_not_merge_virtual_hosts(tmp_path):
    """Two host names resolving to the same IP must not share stored responses."""
    res = run_node(tmp_path, r"""
async function main () {
  const hits = {}
  const v = await vhost(hits)
  const d = new Agent().compose(interceptors.cache(), interceptors.dns({ lookup: fixedLookup }))
  const first = await get(d, '/home', { origin: `http://attacker.example:${v.port}` })
  const second = await get(d, '/home', { origin: `http://trusted.example:${v.port}` })
  const third = await get(d, '/home', { origin: `http://trusted.example:${v.port}` })
  return { first, second, third, hits }
}
""")
    assert_ok(res["first"], "attacker", "attacker request")
    assert_ok(res["second"], "trusted", "trusted request")
    assert_ok(res["third"], "trusted", "trusted repeat")


def test_security_retry_wrapped_client_caller_origin(tmp_path):
    """A retrying wrapper around a client bound to A must not store A's response under origin B."""
    res = run_node(tmp_path, r"""
async function main () {
  const hits = {}
  const a = await labelled('A', hits)
  const b = await labelled('B', hits)
  const store = new cacheStores.MemoryCacheStore()
  const da = new RetryAgent(new Client(a.origin)).compose(interceptors.cache({ store }))
  const db = new Client(b.origin).compose(interceptors.cache({ store }))
  const planted = await get(da, '/feed', { origin: b.origin })
  const victim = await get(db, '/feed')
  return { planted, victim }
}
""")
    assert_ok(res["victim"], "B", "victim behind shared store")


def test_security_legacy_wrapped_client_caller_origin(tmp_path):
    """A legacy-handler wrapper around a client bound to A must not store A's response under origin B."""
    res = run_node(tmp_path, r"""
async function main () {
  const hits = {}
  const a = await labelled('A', hits)
  const b = await labelled('B', hits)
  const store = new cacheStores.MemoryCacheStore()
  const da = new Dispatcher1Wrapper(new Client(a.origin)).compose(interceptors.cache({ store }))
  const db = new Client(b.origin).compose(interceptors.cache({ store }))
  const planted = await get(da, '/feed', { origin: b.origin })
  const victim = await get(db, '/feed')
  return { planted, victim }
}
""")
    assert_ok(res["victim"], "B", "victim behind shared store")


def test_security_coalescing_across_multi_upstream_pools(tmp_path):
    """Concurrent identical requests on pools with different upstreams must not be merged."""
    res = run_node(tmp_path, r"""
async function main () {
  const hits = {}
  const h = holdSpec('/dd')
  const a = await labelled('A', hits, h)
  const b = await labelled('B', hits)
  const dd = interceptors.deduplicate()
  const da = new BalancedPool(a.origin).compose(dd)
  const db = new BalancedPool(b.origin).compose(dd)
  const pa = get(da, '/dd')
  await Promise.race([h.arrived.promise, pa])
  const pb = get(db, '/dd')
  h.release.resolve()
  const [ra, rb] = await Promise.all([pa, pb])
  return { ra, rb }
}
""")
    assert_ok(res["ra"], "A", "first pool")
    assert_ok(res["rb"], "B", "second pool")


def test_security_coalescing_bound_client_caller_origin(tmp_path):
    """An in-flight request to A labelled as B must not be joined by a real request to B."""
    res = run_node(tmp_path, r"""
async function main () {
  const hits = {}
  const h = holdSpec('/dd')
  const a = await labelled('A', hits, h)
  const b = await labelled('B', hits)
  const dd = interceptors.deduplicate()
  const da = new Client(a.origin).compose(dd)
  const db = new Client(b.origin).compose(dd)
  const pa = get(da, '/dd', { origin: b.origin })
  await Promise.race([h.arrived.promise, pa])
  const pb = get(db, '/dd')
  h.release.resolve()
  const [ra, rb] = await Promise.all([pa, pb])
  return { ra, rb }
}
""")
    assert_ok(res["rb"], "B", "victim request")


# ---------------------------------------------------------------- functional


def test_functional_single_origin_client_and_pool_reuse_responses(tmp_path):
    """Storage on a single-origin Client/Pool still serves repeated requests from storage."""
    res = run_node(tmp_path, r"""
async function main () {
  const out = {}
  for (const [name, make] of [['Client', o => new Client(o)], ['Pool', o => new Pool(o)]]) {
    const hits = {}
    const a = await labelled('A', hits)
    const d = make(a.origin).compose(interceptors.cache())
    const results = [
      await get(d, '/f'), await get(d, '/f'),
      await get(d, '/g', { origin: a.origin }), await get(d, '/g', { origin: a.origin })
    ]
    out[name] = { results, hits }
  }
  return out
}
""")
    for name in ("Client", "Pool"):
        for r in res[name]["results"]:
            assert_ok(r, "A", name)
        hits = res[name]["hits"]
        assert hits.get("A /f") == 1, f"{name}: repeated plain request was not reused: {hits}"
        assert hits.get("A /g") == 1, f"{name}: repeated request with own origin was not reused: {hits}"


def test_functional_agent_stores_per_origin(tmp_path):
    """An Agent with storage keeps separate, reusable entries per origin."""
    res = run_node(tmp_path, r"""
async function main () {
  const hits = {}
  const a = await labelled('A', hits)
  const b = await labelled('B', hits)
  const d = new Agent().compose(interceptors.cache())
  const results = [
    await get(d, '/p', { origin: a.origin }),
    await get(d, '/p', { origin: a.origin }),
    await get(d, '/p', { origin: b.origin }),
    await get(d, '/p', { origin: b.origin })
  ]
  return { results, hits }
}
""")
    for r, expected in zip(res["results"], ["A", "A", "B", "B"]):
        assert_ok(r, expected, "agent")
    assert res["hits"].get("A") == 1 and res["hits"].get("B") == 1, res["hits"]


def test_functional_storage_with_custom_lookup_same_host(tmp_path):
    """Storage combined with a custom host lookup still reuses responses for the same host name."""
    res = run_node(tmp_path, r"""
async function main () {
  const hits = {}
  const v = await vhost(hits)
  const d = new Agent().compose(interceptors.cache(), interceptors.dns({ lookup: fixedLookup }))
  const origin = `http://trusted.example:${v.port}`
  const results = [await get(d, '/home', { origin }), await get(d, '/home', { origin })]
  return { results, hits }
}
""")
    for r in res["results"]:
        assert_ok(r, "trusted", "trusted")
    assert res["hits"].get("trusted") == 1, res["hits"]


def test_functional_redirect_target_is_reused(tmp_path):
    """A response reached by following a 3xx to another host is stored for that host."""
    res = run_node(tmp_path, r"""
async function main () {
  let hitsB = 0
  const serverB = createServer((req, res) => {
    hitsB++
    res.writeHead(200, { 'cache-control': 'public, max-age=300', 'x-origin': 'B' })
    res.end('B')
  })
  await listen(serverB)
  const originB = `http://127.0.0.1:${serverB.address().port}`
  const serverA = createServer((req, res) => {
    res.writeHead(302, { location: `${originB}/final` })
    res.end()
  })
  await listen(serverA)
  const originA = `http://127.0.0.1:${serverA.address().port}`
  const d = new Agent().compose(interceptors.cache(), interceptors.redirect({ maxRedirections: 1 }))
  const first = await get(d, '/start', { origin: originA })
  const second = await get(d, '/final', { origin: originB })
  return { first, second, hitsB }
}
""")
    assert_ok(res["first"], "B", "redirected request")
    assert_ok(res["second"], "B", "direct request")
    assert res["hitsB"] == 1, res


def test_functional_coalescing_same_origin(tmp_path):
    """Identical concurrent requests to one origin are still merged into one upstream call."""
    res = run_node(tmp_path, r"""
async function main () {
  const hits = {}
  const h = holdSpec('/dd')
  const a = await labelled('A', hits, h)
  const d = new Client(a.origin).compose(interceptors.deduplicate())
  const p1 = get(d, '/dd')
  await Promise.race([h.arrived.promise, p1])
  const p2 = get(d, '/dd')
  h.release.resolve()
  const [r1, r2] = await Promise.all([p1, p2])
  return { r1, r2, hits }
}
""")
    assert_ok(res["r1"], "A", "first")
    assert_ok(res["r2"], "A", "second")
    assert res["hits"].get("A") == 1, res["hits"]


def test_functional_origins_allow_list(tmp_path):
    """The origins allow-list still enables storage for listed origins (string, uppercase, regex) and skips others."""
    res = run_node(tmp_path, r"""
async function main () {
  const hits = {}
  const a = await labelled('A', hits)
  const allow = new Agent().compose(interceptors.cache({ origins: [a.origin] }))
  const upper = new Agent().compose(interceptors.cache({ origins: [a.origin.toUpperCase()] }))
  const regex = new Agent().compose(interceptors.cache({ origins: [/^http:\/\/127\.0\.0\.1:\d+$/] }))
  const deny = new Agent().compose(interceptors.cache({ origins: ['http://not-listed.example'] }))
  const o = { origin: a.origin }
  const results = [
    await get(allow, '/allow', o), await get(allow, '/allow', o),
    await get(upper, '/upper', o), await get(upper, '/upper', o),
    await get(regex, '/regex', o), await get(regex, '/regex', o),
    await get(deny, '/deny', o), await get(deny, '/deny', o)
  ]
  return { results, hits }
}
""")
    for r in res["results"]:
        assert_ok(r, "A", "allow-list")
    hits = res["hits"]
    assert hits.get("A /allow") == 1, hits
    assert hits.get("A /upper") == 1, hits
    assert hits.get("A /regex") == 1, hits
    assert hits.get("A /deny") == 2, hits


def test_functional_multi_upstream_pool_with_interceptors(tmp_path):
    """A pool spreading load over upstreams still returns correct responses with storage and merging attached."""
    res = run_node(tmp_path, r"""
async function main () {
  const hits = {}
  const a = await labelled('A', hits)
  const d = new BalancedPool(a.origin).compose(interceptors.cache(), interceptors.deduplicate())
  const results = [await get(d, '/x'), await get(d, '/x')]
  return { results }
}
""")
    for r in res["results"]:
        assert_ok(r, "A", "balanced")

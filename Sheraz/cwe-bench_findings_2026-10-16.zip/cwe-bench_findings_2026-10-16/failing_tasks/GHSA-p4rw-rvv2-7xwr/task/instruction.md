# Corpus loading reads files that live outside the corpus directory

## Summary
When an application loads a corpus with NLTK's corpus-reading classes, the library is supposed to treat the corpus directory it is pointed at as a closed sandbox: it should only ever read files that live inside that directory. We found that this boundary is not actually enforced for several of the reader types. If a *symbolic link* is present inside the corpus directory, loading the corpus silently follows the link to wherever it points and reads that file, even when the destination is completely outside the corpus directory.

## Impact
Many deployments populate a corpus directory from a semi-trusted source: a corpus archive downloaded from a third party, a shared folder, or a per-user upload area in a multi-tenant service. An attacker who can drop a single symlink into that directory (or ship an archive that unpacks to one) can make the application read arbitrary files on the host — configuration, credentials, private keys — because the file contents flow straight back out through the ordinary reader return values. This is a classic link-following / sandbox-escape (CWE-22 / CWE-59) and can be an information-disclosure pivot.

## How to reproduce the symptom
1. Create a directory and treat it as a corpus root.
2. Put a sentinel secret file *outside* that directory.
3. Inside the directory, create a symbolic link (named so the reader picks it up) that points at the outside secret.
4. Load the corpus through the normal reader API.

Observed: the reader opens the link target and parses/returns the outside file's contents. Expected: the reader must refuse anything that resolves outside the corpus root.

## Expected behavior
File access performed while loading a corpus must stay confined to the corpus directory the reader was given. Any entry that, once links are resolved, lands outside that directory must be rejected rather than read. Ordinary corpus files that genuinely live inside the directory (plain text tables, XML documents, thesaurus/LISP files, standard-format marker files, etc.) must keep loading exactly as before. The gap exists in more than one reader and is reachable through more than one of the public loading APIs, so each affected path needs to honor the same containment rule.

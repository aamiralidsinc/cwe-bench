import os

import pytest

from nltk import data as nltk_data
from nltk import pathsec
from nltk.corpus.reader import (
    CrubadanCorpusReader,
    LinThesaurusCorpusReader,
    MTECorpusReader,
)
from nltk.toolbox import ToolboxData

SECRET = "SECRET_OUTSIDE_ROOT_MARKER"

MTE_XML = (
    '<?xml version="1.0" encoding="utf-8"?>\n'
    "<TEI><text><body><div><div><p><s>"
    "<w>hello</w><w>world</w>"
    "</s></p></div></div></body></text></TEI>\n"
)


def assert_blocked(fn):
    """Require that fn refuses (raises) instead of returning out-of-root data."""
    try:
        fn()
    except Exception:
        return
    pytest.fail("expected the out-of-root access to be rejected, but it succeeded")


def _symlink(target, link):
    try:
        os.symlink(str(target), str(link))
    except (OSError, NotImplementedError):
        pytest.skip("symlinks not supported on this platform")


@pytest.fixture(autouse=True)
def _sandbox(monkeypatch):
    """Enforce the sandbox and give each test a private, extendable data path."""
    monkeypatch.setattr(pathsec, "ENFORCE", True)
    monkeypatch.setattr(nltk_data, "path", list(nltk_data.path))
    pathsec._ALLOWED_ROOTS_CACHE = None
    yield
    pathsec._ALLOWED_ROOTS_CACHE = None


def _trust(root):
    nltk_data.path.insert(0, str(root))
    pathsec._ALLOWED_ROOTS_CACHE = None


def _dirs(tmp_path, name):
    root = tmp_path / name / "corpus"
    outside = tmp_path / name / "outside"
    root.mkdir(parents=True)
    outside.mkdir(parents=True)
    _trust(root)
    return root, outside


# --------------------------------------------------------------------------
# Security tests: hostile symlink inside the root must not leak outside files.
# --------------------------------------------------------------------------


def test_security_lin_thesaurus_symlink_escape(tmp_path):
    """A thesaurus file that is a symlink out of root must not be read."""
    root, outside = _dirs(tmp_path, "lin")
    secret = outside / "secret.lsp"
    secret.write_text(SECRET + "\n")
    _symlink(secret, root / "simA.lsp")
    assert_blocked(lambda: LinThesaurusCorpusReader(str(root)))


def test_security_crubadan_mapper_symlink_escape(tmp_path):
    """The language-table file, if a symlink out of root, must not be read."""
    root, outside = _dirs(tmp_path, "cru_map")
    secret = outside / "secret.txt"
    secret.write_text(SECRET + "\n")
    _symlink(secret, root / "table.txt")
    assert_blocked(lambda: CrubadanCorpusReader(str(root), r".*\.txt"))


def test_security_crubadan_ngram_symlink_escape(tmp_path):
    """The per-language n-gram file, if a symlink out of root, must not be read."""
    CrubadanCorpusReader._all_lang_freq = {}
    root, outside = _dirs(tmp_path, "cru_ng")
    (root / "table.txt").write_text("xx\tzz\n")
    secret = outside / "secret.txt"
    secret.write_text("5 abc\n")
    _symlink(secret, root / "xx-3grams.txt")
    reader = CrubadanCorpusReader(str(root), r".*\.txt")
    assert_blocked(lambda: reader.lang_freq("zz"))


def test_security_mte_words_symlink_escape(tmp_path):
    """An MTE corpus file that is a symlink out of root must not be opened."""
    root, outside = _dirs(tmp_path, "mte")
    secret = outside / "secret.xml"
    secret.write_text(SECRET + "\n")
    _symlink(secret, root / "test.xml")
    reader = MTECorpusReader(str(root), r".*\.xml")
    assert_blocked(lambda: reader.words())


def test_security_toolbox_symlink_escape(tmp_path):
    """A standard-format marker file that is a symlink out of root must not open."""
    root, outside = _dirs(tmp_path, "tbx")
    secret = outside / "secret.dic"
    secret.write_text(SECRET + "\n")
    link = root / "rotokas.dic"
    _symlink(secret, link)
    assert_blocked(lambda: ToolboxData(str(link), encoding="utf-8"))


# --------------------------------------------------------------------------
# Functional tests: genuine in-root corpora must keep loading normally.
# --------------------------------------------------------------------------


def test_functional_lin_thesaurus_in_root(tmp_path):
    """A genuine in-root thesaurus file still loads and exposes synonyms."""
    root, _ = _dirs(tmp_path, "lin_ok")
    (root / "simA.lsp").write_text(
        '(business (desc 1.000) 2.0\n"enterprise"\t0.650\n))\n'
    )
    reader = LinThesaurusCorpusReader(str(root))
    assert "enterprise" in reader.synonyms("business", fileid="simA.lsp")


def test_functional_crubadan_mapper_in_root(tmp_path):
    """A genuine in-root language table still loads."""
    root, _ = _dirs(tmp_path, "cru_map_ok")
    (root / "table.txt").write_text("xx\tzz\n")
    reader = CrubadanCorpusReader(str(root), r".*\.txt")
    assert "zz" in reader.langs()


def test_functional_crubadan_ngram_in_root(tmp_path):
    """A genuine in-root n-gram file still loads into a frequency table."""
    CrubadanCorpusReader._all_lang_freq = {}
    root, _ = _dirs(tmp_path, "cru_ng_ok")
    (root / "table.txt").write_text("xx\tzz\n")
    (root / "xx-3grams.txt").write_text("5 abc\n")
    reader = CrubadanCorpusReader(str(root), r".*\.txt")
    assert reader.lang_freq("zz")["abc"] == 5


def test_functional_mte_words_in_root(tmp_path):
    """A genuine in-root MTE file still yields its words."""
    root, _ = _dirs(tmp_path, "mte_ok")
    (root / "test.xml").write_text(MTE_XML)
    reader = MTECorpusReader(str(root), r".*\.xml")
    assert "hello" in list(reader.words())


def test_functional_toolbox_in_root(tmp_path):
    """A genuine in-root standard-format file still parses into records."""
    root, _ = _dirs(tmp_path, "tbx_ok")
    dic = root / "rotokas.dic"
    dic.write_text("\\_sh v3.0  400  Test\n\\lx kaa\n\\ps V\n")
    tree = ToolboxData(str(dic), encoding="utf-8").parse()
    assert tree.findall("record")

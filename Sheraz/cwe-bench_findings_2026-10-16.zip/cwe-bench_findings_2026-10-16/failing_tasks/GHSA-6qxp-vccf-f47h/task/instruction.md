# OAuth client sends pinned credentials to whichever authorization server the MCP server names

## Summary

We run headless MCP clients that authenticate with pre-registered OAuth client credentials. The credentials are either a shared secret or a private-key/JWT assertion. Following the docs, we pin these credentials to the authorization server they were registered with, using the documented `expectedIssuer` option. We understood that a pinned credential is never presented to any other authorization server.

That guarantee does not hold across the SDK's public OAuth surface. The MCP server chooses the authorization server, and the client should not trust the MCP server. A malicious or compromised MCP server can advertise its own authorization server, or a caller can be steered toward one. Several paths will then still POST to that server's token endpoint with our `client_id` and secret (HTTP Basic) or our client assertion. The attacker receives long-lived machine credentials that work at our real authorization server.

## Impact

- Client secrets and client assertions are disclosed to a third party.
- The attacker can mint tokens as our service at the legitimate authorization server.
- The pin gives a false sense of safety. Some code paths enforce it and others do not, so a deployment that "did the right thing" is still exposed.

## Reproduction (behaviour level)

1. Construct the SDK's client-credentials provider with a sentinel secret, pinned to `https://as-one.example.com`.
2. Ask the SDK to perform a single token request with that provider against `https://as-two.example.com`, supplying that server's metadata.
3. Observe the outgoing traffic. A POST goes to `https://as-two.example.com/token` with `Authorization: Basic <client_id:secret>`, and no error is raised.

The signed-key and static-assertion providers behave the same way.

## Expected behaviour

**Security property:** credentials bound to one authorization server must never be sent to a different one. This must hold whichever public entry point triggers the request and however the client authenticates. The operation should fail visibly and send nothing.

**Legitimate use that must keep working:**

- Bound credentials still obtain tokens from their own server.
- An issuer written with or without a trailing slash names the same server.
- Credentials with no recorded binding behave as today.
- A provider with no client information at all, including one that returns `null`, behaves as today.
- Providers that persist values by parsing them with the SDK's exported token and client-information schemas can still refresh at the server that issued them.
- Token responses returned to callers do not gain extra fields.

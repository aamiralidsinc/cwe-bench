"""Hidden regression tests: OAuth client credentials must stay bound to their authorization server."""
import json
import os
import shutil
import subprocess
import uuid
from pathlib import Path

import pytest

REPO_ROOT = Path(os.environ.get("REPO_ROOT", os.getcwd())).resolve()
CLIENT_DIR = REPO_ROOT / "packages" / "client"

TS_SOURCE = r"""
import { describe, expect, it, vi } from 'vitest';
import { OAuthClientInformationSchema, OAuthTokensSchema } from '@modelcontextprotocol/core-internal';
import { auth, fetchToken, refreshAuthorization } from '../../src/client/auth';
import { ClientCredentialsProvider, PrivateKeyJwtProvider, StaticPrivateKeyJwtProvider } from '../../src/client/authExtensions';

const AS_ONE = 'https://as-one.example.com';
const AS_TWO = 'https://as-two.example.com';
const SERVER = 'https://api.example.com/mcp';
const REDIRECT = 'http://localhost:3000/callback';

function asMetadata(origin: string, issuer: string = origin): any {
    return {
        issuer,
        authorization_endpoint: origin + '/authorize',
        token_endpoint: origin + '/token',
        registration_endpoint: origin + '/register',
        response_types_supported: ['code'],
        code_challenge_methods_supported: ['S256']
    };
}

function makeServer(initial: string, tokenExtra: Record<string, unknown> = {}) {
    let active = initial;
    const calls: Array<{ origin: string; path: string; auth: string | null; body: string }> = [];
    const fetchFn = async (input: any, init?: any): Promise<Response> => {
        const isReq = typeof Request !== 'undefined' && input instanceof Request;
        const u = new URL(String(isReq ? input.url : input));
        const headers = new Headers(init?.headers ?? (isReq ? input.headers : undefined));
        const body = init?.body !== undefined && init?.body !== null ? String(init.body) : '';
        calls.push({ origin: u.origin, path: u.pathname, auth: headers.get('authorization'), body });
        if (u.pathname.startsWith('/.well-known/oauth-protected-resource')) {
            return Response.json({ resource: SERVER, authorization_servers: [active] });
        }
        if (u.pathname.startsWith('/.well-known/oauth-authorization-server')) {
            return Response.json(asMetadata(u.origin));
        }
        if (u.pathname === '/register') {
            return Response.json(
                { client_id: 'registered-cid', client_secret: 'registered-secret', redirect_uris: [REDIRECT] },
                { status: 201 }
            );
        }
        if (u.pathname === '/token') {
            return Response.json({ access_token: 'at-' + u.host, token_type: 'Bearer', refresh_token: 'rt-new', ...tokenExtra });
        }
        return new Response(null, { status: 404 });
    };
    return {
        fetchFn,
        calls,
        switchTo(o: string) {
            active = o;
        },
        tokenCallsTo(origin: string) {
            return calls.filter(c => c.origin === origin && c.path === '/token');
        }
    };
}

async function settle(p: Promise<any>): Promise<{ ok: boolean; value?: any; error?: any }> {
    try {
        return { ok: true, value: await p };
    } catch (error) {
        return { ok: false, error };
    }
}

function customProvider(info: () => any, extra: Record<string, any> = {}): any {
    return {
        get redirectUrl() {
            return undefined;
        },
        get clientMetadata() {
            return { client_name: 't', redirect_uris: [], grant_types: ['client_credentials'] };
        },
        clientInformation: info,
        tokens: () => undefined,
        saveTokens: () => {},
        redirectToAuthorization: () => {},
        saveCodeVerifier: () => {},
        codeVerifier: () => 'v',
        prepareTokenRequest: () => new URLSearchParams({ grant_type: 'client_credentials' }),
        ...extra
    };
}

function storageProvider(storage: Map<string, string>): any {
    return {
        get redirectUrl() {
            return REDIRECT;
        },
        get clientMetadata() {
            return { client_name: 't', redirect_uris: [REDIRECT] };
        },
        clientInformation: () =>
            storage.has('info') ? OAuthClientInformationSchema.parseAsync(JSON.parse(storage.get('info')!)) : undefined,
        saveClientInformation: (i: any) => void storage.set('info', JSON.stringify(i)),
        tokens: () => (storage.has('tokens') ? OAuthTokensSchema.parseAsync(JSON.parse(storage.get('tokens')!)) : undefined),
        saveTokens: (t: any) => void storage.set('tokens', JSON.stringify(t)),
        redirectToAuthorization: () => {},
        saveCodeVerifier: () => {},
        codeVerifier: () => 'verifier'
    };
}

function seedStorage(storage: Map<string, string>) {
    storage.set('info', JSON.stringify({ client_id: 'cid', client_secret: 'SENTINEL-SECRET-S', issuer: AS_ONE }));
    storage.set(
        'tokens',
        JSON.stringify({ access_token: 'at-old', token_type: 'Bearer', refresh_token: 'SENTINEL-RT', issuer: AS_ONE })
    );
}

describe('hidden-sep2352', () => {
    it('SEC_CCP_BOUND_NOT_SENT', async () => {
        const warn = vi.spyOn(console, 'warn').mockImplementation(() => {});
        const srv = makeServer(AS_ONE);
        const p = new ClientCredentialsProvider({ clientId: 'cid', clientSecret: 'SENTINEL-SECRET-1', expectedIssuer: AS_ONE } as any);
        const r = await settle(fetchToken(p as any, AS_TWO, { metadata: asMetadata(AS_TWO), fetchFn: srv.fetchFn } as any));
        expect(r.ok).toBe(false);
        expect(srv.tokenCallsTo(AS_TWO)).toEqual([]);
        expect(srv.calls.some(c => c.body.includes('SENTINEL') || (c.auth ?? '').includes(btoa('cid:SENTINEL-SECRET-1')))).toBe(false);
        warn.mockRestore();
    });

    it('SEC_STATIC_ASSERTION_NOT_SENT', async () => {
        const warn = vi.spyOn(console, 'warn').mockImplementation(() => {});
        const srv = makeServer(AS_ONE);
        const p = new StaticPrivateKeyJwtProvider({
            clientId: 'cid',
            jwtBearerAssertion: 'SENTINEL-ASSERTION',
            expectedIssuer: AS_ONE
        } as any);
        const r = await settle(fetchToken(p as any, AS_TWO, { metadata: asMetadata(AS_TWO), fetchFn: srv.fetchFn } as any));
        expect(r.ok).toBe(false);
        expect(srv.tokenCallsTo(AS_TWO)).toEqual([]);
        expect(srv.calls.some(c => c.body.includes('SENTINEL-ASSERTION'))).toBe(false);
        warn.mockRestore();
    });

    it('SEC_PRIVATE_KEY_JWT_NOT_SENT', async () => {
        const warn = vi.spyOn(console, 'warn').mockImplementation(() => {});
        const srv = makeServer(AS_ONE);
        const p = new PrivateKeyJwtProvider({
            clientId: 'cid',
            privateKey: 'k'.repeat(64),
            algorithm: 'HS256',
            expectedIssuer: AS_ONE
        } as any);
        const r = await settle(fetchToken(p as any, AS_TWO, { metadata: asMetadata(AS_TWO), fetchFn: srv.fetchFn } as any));
        expect(r.ok).toBe(false);
        expect(srv.tokenCallsTo(AS_TWO)).toEqual([]);
        warn.mockRestore();
    });

    it('SEC_NO_METADATA_URL_ONLY', async () => {
        const warn = vi.spyOn(console, 'warn').mockImplementation(() => {});
        const srv = makeServer(AS_ONE);
        const p = customProvider(() => ({ client_id: 'cid', client_secret: 'SENTINEL-SECRET-3', issuer: AS_ONE }));
        const r = await settle(fetchToken(p, new URL(AS_TWO), { fetchFn: srv.fetchFn } as any));
        expect(r.ok).toBe(false);
        expect(srv.tokenCallsTo(AS_TWO)).toEqual([]);
        expect(srv.calls.some(c => (c.auth ?? '').includes(btoa('cid:SENTINEL-SECRET-3')) || c.body.includes('SENTINEL'))).toBe(false);
        warn.mockRestore();
    });

    it('SEC_LAZY_CLIENT_INFO', async () => {
        const warn = vi.spyOn(console, 'warn').mockImplementation(() => {});
        const srv = makeServer(AS_ONE);
        let filled: any = undefined;
        const p = customProvider(() => filled, {
            prepareTokenRequest: () => {
                filled = { client_id: 'cid', client_secret: 'SENTINEL-LAZY', issuer: AS_ONE };
                return new URLSearchParams({ grant_type: 'client_credentials' });
            }
        });
        const r = await settle(fetchToken(p, AS_TWO, { metadata: asMetadata(AS_TWO), fetchFn: srv.fetchFn } as any));
        expect(r.ok).toBe(false);
        expect(srv.tokenCallsTo(AS_TWO)).toEqual([]);
        warn.mockRestore();
    });

    it('SEC_SCHEMA_ROUNDTRIP_AUTH', async () => {
        const warn = vi.spyOn(console, 'warn').mockImplementation(() => {});
        const storage = new Map<string, string>();
        seedStorage(storage);
        const srv = makeServer(AS_TWO);
        await settle(auth(storageProvider(storage), { serverUrl: SERVER, fetchFn: srv.fetchFn } as any));
        expect(srv.tokenCallsTo(AS_TWO)).toEqual([]);
        const leaked = srv.calls.filter(
            c =>
                c.origin === AS_TWO &&
                (c.body.includes('SENTINEL') || (c.auth ?? '').includes(btoa('cid:SENTINEL-SECRET-S')))
        );
        expect(leaked).toEqual([]);
        warn.mockRestore();
    });

    it('FUNC_CCP_SAME_AS', async () => {
        const warn = vi.spyOn(console, 'warn').mockImplementation(() => {});
        const srv = makeServer(AS_ONE);
        const p = new ClientCredentialsProvider({ clientId: 'cid', clientSecret: 'sec', expectedIssuer: AS_ONE } as any);
        const tokens = await fetchToken(p as any, AS_ONE, { metadata: asMetadata(AS_ONE), fetchFn: srv.fetchFn } as any);
        expect(tokens.access_token).toBe('at-as-one.example.com');
        expect(srv.tokenCallsTo(AS_ONE).map(c => c.auth)).toEqual([`Basic ${btoa('cid:sec')}`]);
        warn.mockRestore();
    });

    it('FUNC_TRAILING_SLASH', async () => {
        const warn = vi.spyOn(console, 'warn').mockImplementation(() => {});
        const srv = makeServer(AS_ONE);
        const p = new ClientCredentialsProvider({ clientId: 'cid', clientSecret: 'sec', expectedIssuer: AS_ONE + '/' } as any);
        const tokens = await fetchToken(p as any, AS_ONE, { metadata: asMetadata(AS_ONE), fetchFn: srv.fetchFn } as any);
        expect(tokens.access_token).toBeTruthy();
        expect(srv.tokenCallsTo(AS_ONE)).toHaveLength(1);
        warn.mockRestore();
    });

    it('FUNC_UNBOUND_LEGACY', async () => {
        const warn = vi.spyOn(console, 'warn').mockImplementation(() => {});
        const srv = makeServer(AS_TWO);
        const p = customProvider(() => ({ client_id: 'cid', client_secret: 'legacy' }));
        const tokens = await fetchToken(p, AS_TWO, { metadata: asMetadata(AS_TWO), fetchFn: srv.fetchFn } as any);
        expect(tokens.access_token).toBeTruthy();
        expect(srv.tokenCallsTo(AS_TWO).map(c => c.auth)).toEqual([`Basic ${btoa('cid:legacy')}`]);
        warn.mockRestore();
    });

    it('FUNC_NULL_CLIENT_INFO', async () => {
        const warn = vi.spyOn(console, 'warn').mockImplementation(() => {});
        const srv = makeServer(AS_ONE);
        const p = customProvider(() => null);
        const tokens = await fetchToken(p, AS_ONE, { metadata: asMetadata(AS_ONE), fetchFn: srv.fetchFn } as any);
        expect(tokens.access_token).toBeTruthy();
        const calls = srv.tokenCallsTo(AS_ONE);
        expect(calls).toHaveLength(1);
        expect(calls[0]!.auth).toBeNull();
        warn.mockRestore();
    });

    it('FUNC_SCHEMA_ROUNDTRIP_SAME_AS', async () => {
        const warn = vi.spyOn(console, 'warn').mockImplementation(() => {});
        const storage = new Map<string, string>();
        seedStorage(storage);
        const srv = makeServer(AS_ONE);
        const result = await auth(storageProvider(storage), { serverUrl: SERVER, fetchFn: srv.fetchFn } as any);
        expect(result).toBe('AUTHORIZED');
        const calls = srv.tokenCallsTo(AS_ONE);
        expect(calls).toHaveLength(1);
        expect(calls[0]!.body).toContain('refresh_token=SENTINEL-RT');
        warn.mockRestore();
    });

    it('FUNC_REFRESH_NO_ISSUER_FIELD', async () => {
        const warn = vi.spyOn(console, 'warn').mockImplementation(() => {});
        const srv = makeServer(AS_ONE, { issuer: 'https://other.example.com' });
        const tokens: any = await refreshAuthorization(AS_ONE, {
            metadata: asMetadata(AS_ONE),
            clientInformation: { client_id: 'cid' },
            refreshToken: 'rt',
            fetchFn: srv.fetchFn
        } as any);
        expect(tokens.access_token).toBeTruthy();
        expect(tokens).not.toHaveProperty('issuer');
        warn.mockRestore();
    });

    it('FUNC_CCP_AUTH_E2E', async () => {
        const warn = vi.spyOn(console, 'warn').mockImplementation(() => {});
        const srv = makeServer(AS_ONE);
        const p = new ClientCredentialsProvider({ clientId: 'cid', clientSecret: 'sec', expectedIssuer: AS_ONE } as any);
        const result = await auth(p as any, { serverUrl: SERVER, fetchFn: srv.fetchFn } as any);
        expect(result).toBe('AUTHORIZED');
        expect(srv.tokenCallsTo(AS_ONE).map(c => c.auth)).toEqual([`Basic ${btoa('cid:sec')}`]);
        expect((p as any).tokens()?.access_token).toBe('at-as-one.example.com');
        warn.mockRestore();
    });
});
"""


def _vitest_cmd():
    for cand in (CLIENT_DIR / "node_modules" / ".bin" / "vitest", REPO_ROOT / "node_modules" / ".bin" / "vitest"):
        if cand.exists():
            return [str(cand)]
    if shutil.which("pnpm"):
        return ["pnpm", "exec", "vitest"]
    return ["npx", "--no-install", "vitest"]


@pytest.fixture(scope="module")
def results(tmp_path_factory):
    name = f"__hidden_sep2352_{uuid.uuid4().hex[:8]}.test.ts"
    test_file = CLIENT_DIR / "test" / "client" / name
    out = tmp_path_factory.mktemp("vitest") / "report.json"
    test_file.write_text(TS_SOURCE, encoding="utf-8")
    env = dict(os.environ, CI="1", NO_COLOR="1", FORCE_COLOR="0")
    try:
        proc = subprocess.run(
            _vitest_cmd() + ["run", f"test/client/{name}", "--reporter=json", f"--outputFile={out}"],
            cwd=str(CLIENT_DIR),
            env=env,
            capture_output=True,
            text=True,
            timeout=900,
        )
    finally:
        try:
            test_file.unlink()
        except OSError:
            pass
    data = {}
    if out.exists():
        try:
            data = json.loads(out.read_text(encoding="utf-8"))
        except ValueError:
            data = {}
    table = {}
    for tr in data.get("testResults", []):
        for ar in tr.get("assertionResults", []):
            table[ar.get("title")] = (ar.get("status"), ar.get("failureMessages", []))
    log = (proc.stdout or "")[-3000:] + "\n" + (proc.stderr or "")[-3000:]
    return table, log


def _check(results, title):
    table, log = results
    assert title in table, f"vitest case {title} did not run:\n{log}"
    status, failures = table[title]
    assert status == "passed", f"{title} -> {status}\n" + "\n".join(failures)[:4000]


def test_security_bound_client_secret_not_sent_to_other_as(results):
    """A client-credentials secret pinned to one AS is never posted to another AS's token endpoint."""
    _check(results, "SEC_CCP_BOUND_NOT_SENT")


def test_security_static_assertion_not_sent_to_other_as(results):
    """A pre-built client assertion pinned to one AS is never presented to another AS."""
    _check(results, "SEC_STATIC_ASSERTION_NOT_SENT")


def test_security_private_key_jwt_not_sent_to_other_as(results):
    """A signed private-key-JWT client pinned to one AS does not authenticate to another AS."""
    _check(results, "SEC_PRIVATE_KEY_JWT_NOT_SENT")


def test_security_bound_credentials_without_metadata(results):
    """Bound credentials are not sent when the foreign AS is given only as a URL, without metadata."""
    _check(results, "SEC_NO_METADATA_URL_ONLY")


def test_security_lazily_supplied_client_info_checked(results):
    """Client information a provider supplies while preparing the request is still bound to its AS."""
    _check(results, "SEC_LAZY_CLIENT_INFO")


def test_security_schema_roundtrip_keeps_binding(results):
    """Credentials persisted and read back through the SDK schemas are not replayed to a new AS."""
    _check(results, "SEC_SCHEMA_ROUNDTRIP_AUTH")


def test_functional_bound_credentials_work_with_own_as(results):
    """Bound client credentials still obtain tokens from their own AS."""
    _check(results, "FUNC_CCP_SAME_AS")


def test_functional_trailing_slash_issuer_equivalent(results):
    """An issuer pinned with a trailing slash still matches the same AS."""
    _check(results, "FUNC_TRAILING_SLASH")


def test_functional_unbound_legacy_credentials_still_work(results):
    """Credentials with no recorded binding keep working as before."""
    _check(results, "FUNC_UNBOUND_LEGACY")


def test_functional_null_client_information_treated_as_absent(results):
    """A provider that returns null client information still makes an unauthenticated token request."""
    _check(results, "FUNC_NULL_CLIENT_INFO")


def test_functional_schema_roundtrip_refresh_same_as(results):
    """Schema-roundtripped storage still refreshes tokens at the AS that issued them."""
    _check(results, "FUNC_SCHEMA_ROUNDTRIP_SAME_AS")


def test_functional_token_response_has_no_extra_issuer(results):
    """Token responses that include an issuer field do not surface it in the returned tokens."""
    _check(results, "FUNC_REFRESH_NO_ISSUER_FIELD")


def test_functional_client_credentials_end_to_end(results):
    """The full auth flow with a pinned client-credentials provider still authorizes."""
    _check(results, "FUNC_CCP_AUTH_E2E")

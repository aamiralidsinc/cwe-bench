# Batch 4: the 18 restart candidates, stages 3-6

- Candidates (`--only`): GHSA-vp8m-p9jh-q5pm GHSA-hqr4-qq8f-hg3x GHSA-hmq2-7hp6-7crh GHSA-2q42-4q24-7rgv GHSA-3wxw-xv34-2frg GHSA-5jq2-8x83-x246 GHSA-hxh3-vqpv-xpqv GHSA-jggr-w7fw-pc2j GHSA-68w4-83fh-f2w8 GHSA-77xj-x4rm-935c GHSA-8r5x-fm3f-whwj GHSA-r4xh-jqrq-34v2 GHSA-9q47-3cm2-2rp8 GHSA-68fv-2mgg-jv7q GHSA-24ch-f2g6-9hhh GHSA-r223-96jv-q533 GHSA-qf28-8hc6-vwrp GHSA-p4rw-rvv2-7xwr
- Agent: Claude Code (both models), egress proxy v2, separate grader container.
- Generation: Opus 5.5 with the Opus 4.8 fallback on safety refusals; 64k output tokens; 1-hour calls; stage-4 checks in the prompt; repo map + callers.
- Validation: rubric, recall probe, isolation audit + image scan, oracle x2, pre-patch, existing repo tests (npm too), shallow / removal / alternative fix checks.
- Models: 3 + 3 attempts, 2-hour limit; timeouts are not counted as failures.

## Launch (parallel)
- 01_generate-validate.log: stages 3-4 (`--workers 5`: 3 generations, 3 validations at once)
- 02_model-runner.log: stages 5-6 in follow mode, 5 tasks in parallel (MAX_CONTAINERS=10); Docker VM raised to 10 CPUs / 12 GB

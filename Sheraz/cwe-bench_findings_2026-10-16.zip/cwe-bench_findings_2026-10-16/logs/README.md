# Pipeline logs

One folder per run: `YYYY-MM-DD_HHMM_<what>_<detail>/`. A run with several steps keeps one numbered file per step
(`01_generate.log`, `02_validate-evaluate.log`, ...). `pipeline.jsonl` is the structured log of every run (used by
`run_pipeline.py --watch`).

| Folder | What it was | Result (see C_RESULTS.md) |
|---|---|---|
| 2026-10-14_1706_batch1_eval_pyload-mcp-sdk_30min | First model runs, terminus-2, 30-min limit | pyload: DeepSeek solved, MiMo timed out; MCP SDK: both failed (most runs timed out) |
| 2026-10-15_0841_mcp-sdk_rerun-2h_terminus2 | MCP SDK re-run, 2-hour limit | DeepSeek failed 3/3 (0.92); MiMo timed out 3/3 (rejected) |
| 2026-10-15_0858_batch2_devalue-ip-address-pypdf | Generate + validate + evaluate batch 2 | devalue, ip-address, pypdf: solved |
| 2026-10-15_1113_batch3_adm-zip | Generate + validate + evaluate batch 3 | adm-zip: both solved |
| 2026-10-15_1511_mining_new-data | Mining/screening for new data (cutoff 2026-08-01, fix series, 400 MB limit) | 123 new screened candidates |
| 2026-10-15_1755_mcp-sdk-6qxp_claude-code_STOPPED-credential-fix | First Claude Code attempt, stopped after 4 min to fix credential forwarding | no result (token not exposed) |
| 2026-10-15_1758_mcp-sdk-6qxp_claude-code_STOPPED-internet-drop | Claude Code run lost to a local internet drop (ECONNRESET in attempts 1-2) | no result (ungraded) |
| 2026-10-15_1824_mcp-sdk-6qxp_claude-code_deepseek-only | MCP SDK re-verification with the Claude Code agent, DeepSeek only, 3 attempts | DeepSeek failed 3/3 (0.92 each, missed the schema round-trip) |
| 2026-10-15_1916_batch4_restart-18_claude-code | Batch 4: the 18 restart candidates (stages 3-6, Claude Code agent) | **hono ACCEPTED** (both failed 3/3, packaged); 11 solved by at least one model; 5 retired; payload validated, its evaluation moved to batch 5 (runner stopped for a Docker restart) |
| 2026-10-16_0302_batch5_top10_claude-code | Batch 5: next top-10 screened candidates + payload's evaluation (stages 3-6, Claude Code agent) | 0 accepted; 6 solved by DeepSeek on attempt 1 (payload import-export, pymongo, httpx2, devalue, pydantic-ai, nltk w3v8); retired: vllm (CUDA), Django + plugin-mcp (safeguards flags); astro + virtualenv await their last rewrite (generation paused). `*_VOID_*` logs = runs with a bad ID list, no effect |

Logs of runs that produced no result (setup failures, a network outage, stopped runs) were removed on 2026-10-15 and
kept compressed in `data/knowledge/archive/removed_logs_2026-10-15.tar.gz`.

# Re-verification: MCP TypeScript SDK (GHSA-6qxp-vccf-f47h) with the Claude Code agent

- Model: DeepSeek V4.1 Flash (`deepseek-flash`, effort max) only - MiMo not run.
- Agent: Harbor `claude-code` 2.1.292, baked into the image; WebSearch/WebFetch disabled.
- Network: agent container on an internal Docker network; egress proxy v2 (keepalive + close logging) allows only the model APIs.
- Grading: separate fresh grader container, agent's source patch only.
- Attempts: 3, one at a time (one agent container), 2-hour limit each.
- Previous result (terminus-2): DeepSeek failed 3/3 at 0.92 (missed schema_roundtrip_keeps_binding).



## Result (19:05)
DeepSeek failed 3/3, all clean (no API errors, no tampering, patch applied in the separate grader): 0.92 each, 9-15 min, 73-88 turns. Every attempt closed 5 of 6 attack variants and left `test_security_schema_roundtrip_keeps_binding` open, then stopped on its own - the same partial fix as with terminus-2.
